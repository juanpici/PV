/**
 * Kazunori Hayashi
* Version 1.0 02/08/2013
 */
public class RMS_GUI
{
	public static void main(String[] args) {
		Controller_GUI cController = new Controller_GUI();
		//cController.mainLoop();
	}
}

